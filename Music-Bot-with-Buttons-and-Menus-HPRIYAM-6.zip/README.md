## 📑 Short Feature
- [x] Music
- [x] Custom Prefix
- [x] SlashCommand
- [x] Custom Filters
- [x] No Database Requirement
- [x] Easy to use

## 🎶 Support Source
- [x] Youtube
- [x] SoundCloud
- [x] Spotify (no api key anymore!)
- [x] Deezer
- [x] Twitch
- [x] Facebook
- [x] Apple
- [x] Https (Radio)

## 🚨 Have a Problem

Join Discord: [HPRIYAM'S CODING HUT](https://discord.gg/JHJDpW7Vgx)
   mention me in chat #general or #coding help and ask problem okay! 👌


## 📎 Requirements

1. Node.js Version 16+ **[Download](https://nodejs.org/en/download/)**
2. Discord Bot Token **[Guide](https://discordjs.guide/preparations/setting-up-a-bot-application.html#creating-your-bot)**
3. Lavalink **[Guide](https://github.com/freyacodes/lavalink)** (switch back to default lavalink!)


## 🛑 Super Requirements 

1. Java 11-13 **[Download JDK13](http://www.mediafire.com/file/m6gk7aoq96db8g0/file)** (i use this here version)
2. Invite **[Access Invite](https://discord.com/api/oauth2/authorize?client_id=CLIENT_ID&permissions=8&scope=bot%20applications.commands)** (replace CLIENT_ID to your bot client id!) for slashcommand!




## 🔩 Features & Commands

> Note: The default prefix is '#'

🎶 **Music Commands!** 

- Play (#play, #p, #pplay)
- Nowplaying (#nowplaying, #np, #now)
- Queue (#q)
- Repeat (#loop (current, all), #repeat (current, all))
- Loopqueue (#loopall, #lq, repeatall)
- Shuffle (#shuffle, mix)
- Volume control (#vol, #v)
- Pause (#pause, #pa)
- Resume (#resume, #r)
- Skip (#skip, #s)
- Skipto (#skipto, #st)
- Clear (#clear)
- Join (#join, #summon)
- Leave (#leave, #dc, #lev, #stop)
- Forward (#forward)
- Seek (#seek)
- Rewind (#rewind)
- Replay (#replay)
- Search (#search)
- 247 (#247)

⏺ **Filter Commands!**
- Bass (#bass)
- Superbass (#superbass, #sb)
- Pop (#pop)
- Treblebass (#treblebass, #tb)
- Soft (#soft)
- Earrape (#earrape, #ear)
- Equalizer (#eq <custom>)
- Speed (#speed )
- Picth (#pitch)
- Vaporwave (#vaporwave)
- Nightcore (#nightcore)
- Bassboost (#bassboost <number -10 - 10>, #bb <number -10 - 10>)
- Rate (#rate)
- Reset (#reset)
- 3d (#3d)
- China (#china)
- Dance (#dance)
- Chipmunk (#chipmunk)
- Darthvader (#darthvader)
- DoubleTime (#doubletime)
- SlowMotion (#slowmotion)
- Tremolo (#tremolo)
- Vibrate (#vibrate)
- Vibrato (#vibrato)
	


## 👏 Credits :)
### ALL CREDITS TO HPRIYAM

- [Discord](https://discord.gg/JHJDpW7Vgx)

- [YouTube](https://youtube.com/c/HPRIYAM)
	
- [Github](https://github.com/hpriyam8)
