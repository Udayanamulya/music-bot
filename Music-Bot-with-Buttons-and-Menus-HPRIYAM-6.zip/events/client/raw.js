module.exports = (client, data) => {
    client.manager.updateVoiceState(data);
};