const chalk = require('chalk');
const { MessageEmbed } = require('discord.js');

module.exports = {
    name: "invite",
    description: "Gives and Invite link for the Bot",
    botPerms: ["SEND_MESSAGES", "EMBED_LINKS", "CONNECT", "SPEAK"],
    ownerOnly: false,

    run: async (interaction, client) => {
    await interaction.deferReply({ ephemeral: false });
    const invite = new MessageEmbed()
        .setTitle(`**Thanks for Inviting ${client.user.username}**`)
        .addField(`${client.user.username} Powered by HPRIYAM`, `**[Invite Me](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands)**`)
        .setTimestamp()
        .setColor("#3498DB");

const row = new MessageActionRow()
    .addComponents(
      new MessageButton()
        .setLabel("Invite ME")
        .setStyle("LINK")
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
    )
    .addComponents(
      new MessageButton()
        .setLabel("YouTube")
        .setStyle("LINK")
        .setURL("https://youtube.com/c/HPRIYAM")
    )
    .addComponents(
      new MessageButton()
        .setLabel("Discord")
        .setStyle("LINK")
        .setURL("https://discord.gg/JHJDpW7Vgx")
    )

    await interaction.editReply({ embeds: [invite], components: [row] });
    }
};