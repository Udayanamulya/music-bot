const chalk = require('chalk');
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    name: "help",
    description: "Shows all the commands of the Bot",
    botPerms: ["SEND_MESSAGES", "EMBED_LINKS", "CONNECT", "SPEAK"],
    ownerOnly: false,

    run: async (interaction, client) => {
    await interaction.deferReply({ ephemeral: false });
    const helpembed = new MessageEmbed()
       .setAuthor(client.user.username + " Slashcommands")
        .setTitle("Slash Commands")
        .addField(`:headphones: **Filter Commands** - (23)`, `\`3d\`, \`bass\`, \`chipmunk\`, \`china\`, \`dance\`, \`darthvader\`, \`equalizer\`, \`nightcore\`, \`earrape\`, \`soft\`, \`slowmo\`, \`speed\`, \`tremolo\`, \`vibrato\`, \`vibrate\`, \`vibrato\`, \`superbass\`, \`pop\`, \`rate\`, \`treblepass\`, \`vaporwave\`, \`pitch\`, \`doubletime\`, \`reset\``)
        .addField(`:shield: **Info/Utility Commands** - (4)`, `\`developer\`, \`help\`, \`invite\`, \`restart\``)
        .addField(`:notes: **Music Commands** - (20)`, `\`247\`, \`clear\`, \`forward\`, \`join\`, \`leave\`, \`loop\`, \`loopall\`, \`nowplaying\`, \`pause\`, \`play\`, \`queue\`, \`replay\`, \`resume\`, \`rewind\`, \`search\`, \`seek\`, \`shuffle\`, \`skip\`, \`skipto\`, \`volume\`, \`seek\`, \`shuffle\`, \`skip\`, \`skipto\`, \`stop\``)
        .setFooter({ text: "Consider Joining the server or Inviting the Bot :) This would help me alot!" })
        .setColor("#3498DB");

    const hpriyamop = new MessageActionRow()
     .addComponents(
     new MessageButton()
     .setLabel("Invite ME")
     .setStyle("LINK")
     .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
     )
    .addComponents(
      new MessageButton()
      .setLabel("Support Server")
      .setStyle("LINK")
      .setURL("https://discord.gg/Zf3ujxQg2f")
    )

    await interaction.editReply({ embeds: [helpembed], components: [hpriyamop] });
    }
};