const chalk = require('chalk');
const { MessageEmbed } = require('discord.js');

module.exports = {
    name: "developer",
    description: "Shows the Information about the Bot Developer",
    botPerms: ["SEND_MESSAGES", "EMBED_LINKS", "CONNECT", "SPEAK"],
    ownerOnly: false,

    run: async (interaction, client) => {
    await interaction.deferReply({ ephemeral: false });
    const hpriyam = new MessageEmbed()
        .setTitle("HPRIYAM | Developer of 40+ Discord Bot's")
        .setDescription("Hey I am Priyam, ``HPRIYAM#5546``<@619139052167364608> and I have developed more than 40 Discord Bot's and I also teach developing bot's on my [YouTube channel](https://youtube.com/c/HPRIYAM) :) \n\ \n\ ***[Invite Tesla (Multipurpose Bot)](https://discord.com/api/oauth2/authorize?client_id=923431582088450068&permissions=8&scope=bot%20applications.commands)*** \n\ \n\ ***[Join my Discord Server](https://discord.gg/JHJDpW7Vgx)***")
        .setFooter({ text: "Consider Joining the server or Inviting the Bot :) This would help me alot!" })
        .setColor("#3498DB");

const row = new MessageActionRow()
    .addComponents(
      new MessageButton()
        .setLabel("Github")
        .setStyle("LINK")
        .setURL("https://github.com/hpriyam8")
    )
    .addComponents(
      new MessageButton()
        .setLabel("YouTube")
        .setStyle("LINK")
        .setURL("https://youtube.com/c/HPRIYAM")
    )
    .addComponents(
      new MessageButton()
        .setLabel("Discord")
        .setStyle("LINK")
        .setURL("https://discord.gg/JHJDpW7Vgx")
    )

    await interaction.editReply({ embeds: [hpriyam], components: [row] });
    }
};