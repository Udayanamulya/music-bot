const MainClient = require("./hpriyam");
const client = new MainClient();
require("http").createServer((req, res) => res.end("Credits to HPRIYAM (don't steal the credits btw :D)")).listen(process.env.PORT || 8080)
client.connect()

module.exports = client; 